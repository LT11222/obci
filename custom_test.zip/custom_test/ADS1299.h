//
//  ADS1299.h
//  Part of the Arduino Library
//  Created by Conor Russomanno, Luke Travis, and Joel Murphy. Summer 2013.
//

#ifndef ____ADS1299__
#define ____ADS1299__

#include <stdio.h>
#include <Arduino.h>
#include <avr/pgmspace.h>
#include "Definitions.h"
#include <spi.h>

#define PIN_DRDY (8)
#define PIN_RST (9)
#define SCK_MHZ (4)
#define _CS1 (10) // ADS chip select
#define DAISY_SS (6)  // ADS Daisy chip select
#define SD_SS (7)  // SD card chip select
#define LIS3DH_SS (5)  // LIS3DH chip select

//Pick which version of OpenBCI you have
#define OPENBCI_V1 (1)    //Sept 2013
#define OPENBCI_V2 (2)    //Oct 24, 2013
#define OPENBCI_V2 (3)	  //April, 2014
#define OPENBCI_NCHAN (8)  // number of EEG channels

//gainCode choices
#define ADS_GAIN01 (0b00000000)
#define ADS_GAIN02 (0b00010000)
#define ADS_GAIN04 (0b00100000)
#define ADS_GAIN06 (0b00110000)
#define ADS_GAIN08 (0b01000000)
#define ADS_GAIN12 (0b01010000)
#define ADS_GAIN24 (0b01100000)

//inputCode choices
#define ADSINPUT_NORMAL (0b00000000)
#define ADSINPUT_SHORTED (0b00000001)
#define ADSINPUT_BIAS_MEAS (0b00000010)
#define ADSINPUT_MVDD (0b00000011)
#define ADSINPUT_TEMP (0b00000100)
#define ADSINPUT_TESTSIG (0b00000101)
#define ADSINPUT_BIAS_DRP (0b00000110)
#define ADSINPUT_BIAL_DRN (0b00000111)


//test signal choices...ADS1299 datasheet page 41
#define ADSTESTSIG_AMP_1X (0b00000000)
#define ADSTESTSIG_AMP_2X (0b00000100)
#define ADSTESTSIG_PULSE_SLOW (0b00000000)
#define ADSTESTSIG_PULSE_FAST (0b00000001)
#define ADSTESTSIG_DCSIG (0b00000011)
#define ADSTESTSIG_NOCHANGE (0b11111111)

//binary communication codes for each packet
#define PCKT_START 0xA0
#define PCKT_END 0xC0

class ADS1299 {
public:
    
    void initialize(int _DRDY, int _RST, int _CS);
    
    //ADS1299 SPI Command Definitions (Datasheet, p35)
    //System Commands
    void WAKEUP();
    void STANDBY();
    void RESET();
    void START();
    void STOP();
    
    //Data Read Commands
    void RDATAC();
    void SDATAC();
    void RDATA();
    
    //Register Read/Write Commands
    byte getDeviceID();
    byte RREG(byte _address);
    void RREGS(byte _address, byte _numRegistersMinusOne);     
    void printRegisterName(byte _address);
    void WREG(byte _address, byte _value); 
    void WREGS(byte _address, byte _numRegistersMinusOne); 
    void printHex(byte _data);
    void updateChannelData();
	void setSRB1(boolean desired_state);

    int DRDY, CS; 		// pin numbers for DRDY and CS 
    int DIVIDER;		// select SPI SCK frequency
    int stat;			// used to hold the status register
    byte regData [24];	// array is used to mirror register data
    long channelData [9];	// array used when reading channel data
    boolean verbose;		// turn on/off Serial feedback
	
	void activateChannel(int N, byte gainCode,byte inputCode); //setup the channel 1-8
	void activateChannel(int, byte, byte, boolean);
    void deactivateChannel(int N);                            //disable given channel 1-8
	
    void configureInternalTestSignal(byte amplitudeCode, byte freqCode);
	
    void start(void);
    void stop(void);
	
    int isDataAvailable(void);
	
	void printAllRegisters(void);
	
private:
	boolean use_N_inputs;
    boolean use_SRB2[OPENBCI_NCHAN];
    boolean isRunning;
    boolean use_SRB1(void);
	
    
    
};

#endif